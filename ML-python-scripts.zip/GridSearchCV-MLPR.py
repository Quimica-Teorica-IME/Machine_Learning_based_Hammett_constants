# Running this script:
#
# Open the command prompt and type:
#
#   python GridSearchCV-MLPR.py <file.csv>
#
# where <file.csv> is one of the following: ALL_sigs_Dq-BENZACID-p.csv, ALL_sigs_Dq-BENZACID-m.csv, or ALL_sigs_Dq-BENZENE.csv
# These files contain both Hammett's parameters from the literature and the variation of atomic charges of the carbon atoms, calculated with ORCA (Mulliken, Löwdin, and Hirshfeld) and Gaussian (ChelpG) software.

from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import GridSearchCV, LeaveOneOut
import sys, pandas as pd

# Defining the cross-validation method.
loo = LeaveOneOut()

# Opening the .csv file containing all the delta-charges and sigmas. Must be informed when calling the script in the prompt.
df = pd.read_csv(sys.argv[1], sep=';')

# Defining the variables: Hammett's constants and delta-atomic charges.
mol = sys.argv[1].split('-')[-1] # This variable "mol" will contain the the ending of the .csv file mentioned above. "m.csv" and "p.csv" mean meta- and para-substituted benzoic acid, respectively. If the .csv file does not contain these suffixes, it means it is the benzene derivatives.

if mol == 'm.csv':
    listSigmas = ['sigM', 'sigR', 'sigI', 'sigM0']
    name = 'META-BENZ-ACID'
elif mol == 'p.csv':
    listSigmas = ['sigP', 'sigR', 'sigI', 'sigP+', 'sigP-', 'sigP0']
    name = 'PARA-BENZ-ACID'
else:
    listSigmas = ['sigM', 'sigM0', 'sigP', 'sigR', 'sigI', 'sigP+', 'sigP-', 'sigP0']
    name = 'BENZENE'

dictCharges = {'Mulliken':['q1M', 'q2M', 'q3M', 'q4M', 'q5M', 'q6M'],
                'Loewdin':['q1L', 'q2L', 'q3L', 'q4L', 'q5L', 'q6L'],
                'Hirshfeld':['q1H', 'q2H', 'q3H', 'q4H', 'q5H', 'q6H'],
                'CHELPG':['q1CG', 'q2CG', 'q3CG', 'q4CG', 'q5CG', 'q6CG']} # Delta-atomic charges.

# Parameters to be tested with the MLP Regressor (MLPR) algorithm.
paramMLPR = {'tol':[1e-6, 1e-4, 1e-7], 'activation':['identity', 'logistic', 'tanh', 'relu'], 'solver':['lbfgs', 'sgd', 'adam'], 'learning_rate':['constant', 'invscaling', 'adaptive']}

# Defining the regressor: MLPR.
reg = MLPRegressor()

# Creating a .txt file with all the results of the GridSearchCV algorithm.
with open('GridSearchCV-MLPR-' + name + '.txt', 'w') as outFile:
    for sigma in listSigmas:
        for keyCh, charge in dictCharges.items():
            newdf = df.dropna(subset=[sigma])
            grid = GridSearchCV(verbose=0, estimator=reg, param_grid=paramMLPR, scoring='accuracy', cv=loo, n_jobs=-1)
            grid.fit(newdf[charge], newdf[sigma])

            outFile.write('\n\t')
            outFile.write('MLP Regressor')
            outFile.write('\n{} vs. {}:\n'.format(sigma, keyCh))
            outFile.write(str(grid.best_params_))
            outFile.write('\n')
            outFile.write(str(grid.best_estimator_))
            outFile.write('\n')
            outFile.write(str(grid.feature_names_in_))
            outFile.write('\n')
            
print('\nJob terminated.\n')