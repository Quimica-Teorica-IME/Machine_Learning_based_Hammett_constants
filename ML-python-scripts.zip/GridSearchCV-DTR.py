# Running this script:
#
# Open the command prompt and type:
#
#   python GridSearchCV-DTR.py <file.csv>
#
# where <file.csv> is one of the following: ALL_sigs_Dq-BENZACID-p.csv, ALL_sigs_Dq-BENZACID-m.csv, or ALL_sigs_Dq-BENZENE.csv
# These files contain both Hammett's parameters from the literature and the variation of atomic charges of the carbon atoms, calculated with ORCA (Mulliken, Löwdin, and Hirshfeld) and Gaussian (ChelpG) software.

from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import GridSearchCV, LeaveOneOut
import sys, pandas as pd

# Defining the cross-validation method.
loo = LeaveOneOut()

# Opening the .csv file containing all the delta-charges and sigmas. Must be informed when calling the script in the prompt.
df = pd.read_csv(sys.argv[1], sep=';')

# Defining the variables: Hammett's constants and delta-atomic charges.
mol = sys.argv[1].split('-')[-1] # This variable "mol" will contain the the ending of the .csv file mentioned above. "m.csv" and "p.csv" mean meta- and para-substituted benzoic acid, respectively. If the .csv file does not contain these suffixes, it means it is the benzene derivatives.

if mol == 'm.csv':
    listSigmas = ['sigM', 'sigR', 'sigI', 'sigM0']
    name = 'META-BENZ-ACID'
elif mol == 'p.csv':
    listSigmas = ['sigP', 'sigR', 'sigI', 'sigP+', 'sigP-', 'sigP0']
    name = 'PARA-BENZ-ACID'
else:
    listSigmas = ['sigM', 'sigM0', 'sigP', 'sigR', 'sigI', 'sigP+', 'sigP-', 'sigP0']
    name = 'BENZENE'

dictCharges = {'Mulliken':['q1M', 'q2M', 'q3M', 'q4M', 'q5M', 'q6M'],
                'Loewdin':['q1L', 'q2L', 'q3L', 'q4L', 'q5L', 'q6L'],
                'Hirshfeld':['q1H', 'q2H', 'q3H', 'q4H', 'q5H', 'q6H'],
                'CHELPG':['q1CG', 'q2CG', 'q3CG', 'q4CG', 'q5CG', 'q6CG']} # Delta-atomic charges.

# Parameters to be tested with the Decision Tree Regressor (DTR) algorithm.
paramDTR = {'splitter':['best', 'random'], 'min_weight_fraction_leaf':[0, 0.1, 0.5], 'min_samples_leaf':list(range(1,7)), 'min_samples_split':list(range(2,6)), 'criterion':['squared_error', 'poisson', 'absolute_error', 'friedman_mse']}

# Defining the regressor: DTR.
reg = DecisionTreeRegressor()

# Creating a .txt file with all the results of the GridSearchCV algorithm.
with open('GridSearchCV-DTR-' + name + '.txt', 'w') as outFile:
    for sigma in listSigmas:
        for keyCh, charge in dictCharges.items():
            newdf = df.dropna(subset=[sigma])
            grid = GridSearchCV(verbose=0, estimator=reg, param_grid=paramDTR, scoring='accuracy', cv=loo, n_jobs=-1)
            grid.fit(newdf[charge], newdf[sigma])
                
            outFile.write('\n\t')
            outFile.write('Decision Tree Regressor')
            outFile.write('\n{} vs. {}:\n'.format(sigma, keyCh))
            outFile.write(str(grid.best_params_))
            outFile.write('\n')
            outFile.write(str(grid.best_estimator_))
            outFile.write('\n')
            outFile.write(str(grid.feature_names_in_))
            outFile.write('\n')

print('\nJob terminated.\n')