# Running this script:
#
# Open the command prompt and type:
#
#   python CrossValidation-LLIC.py <file.csv>
#
# where <file.csv> is one of the following: ALL_sigs_Dq-BENZACID-p.csv, ALL_sigs_Dq-BENZACID-m.csv, or ALL_sigs_Dq-BENZENE.csv
# These files contain both Hammett's parameters from the literature and the variation of atomic charges of the carbon atoms, calculated with ORCA (Mulliken, Löwdin, and Hirshfeld) and Gaussian (ChelpG) software.

from sklearn.model_selection import LeaveOneOut, cross_val_score, cross_val_predict
from sklearn.linear_model import LassoLarsIC
from sklearn.metrics import mean_squared_error, r2_score
from numpy import sqrt
import sys, pandas as pd

# Opening the .csv file containing all the delta-charges and sigmas. Must be informed when calling the script in the prompt.
df = pd.read_csv(sys.argv[1], sep=';')

# Defining the variables: Hammett's constants and delta-atomic charges.
mol = sys.argv[1].split('-')[-1] # This variable "mol" will contain the the ending of the .csv file mentioned above. "m.csv" and "p.csv" mean meta- and para-substituted benzoic acid, respectively. If the .csv file does not contain these suffixes, it means it is the benzene derivatives.

if mol == 'm.csv':
    listSigmas = ['sigM', 'sigR', 'sigI', 'sigM0']
    name = 'META-BENZ-ACID'
elif mol == 'p.csv':
    listSigmas = ['sigP', 'sigR', 'sigI', 'sigP+', 'sigP-', 'sigP0']
    name = 'PARA-BENZ-ACID'
else:
    listSigmas = ['sigM', 'sigM0', 'sigP', 'sigR', 'sigI', 'sigP+', 'sigP-', 'sigP0']
    name = 'BENZENE'

dictCharges = {'Mulliken':['q1M', 'q2M', 'q3M', 'q4M', 'q5M', 'q6M'],
                'Loewdin':['q1L', 'q2L', 'q3L', 'q4L', 'q5L', 'q6L'],
                'Hirshfeld':['q1H', 'q2H', 'q3H', 'q4H', 'q5H', 'q6H'],
                'CHELPG':['q1CG', 'q2CG', 'q3CG', 'q4CG', 'q5CG', 'q6CG']} # Delta-atomic charges.

# Defining the cross-validation method.
loo = LeaveOneOut()

# Defining the model with GridSearchCV-optimized parameters.
model = LassoLarsIC(criterion='aic', eps=0.0001)

# Creating a .txt file with all the results of the Cross-Validation.
for sigma in listSigmas:
    with open('CrossValidation-LLIC-' + sigma + '-' + name + '.txt', 'w') as outFile:
        newdf = df.dropna(subset=[sigma])
        for keyCh, charge in dictCharges.items():
            regr = model.fit(newdf[charge], newdf[sigma])
            Sig_pred_regr = regr.predict(newdf[charge])
            Sig_pred_cv = cross_val_predict(model, newdf[charge], newdf[sigma], cv=loo, n_jobs=-1)
            outFile.write('\n{} vs. {}\n'.format(sigma, keyCh))
            outFile.write('\n')
            outFile.write('\n{} vs. {}\n'.format(regr.coef_, regr.intercept_))
            outFile.write('\n\nPredicted Sigmas (regression)\n\n')
            for i in Sig_pred_regr:
                outFile.write(str(i))
                outFile.write('\n')
            outFile.write('\n\tMSE        -->     {:.3f}'.format(mean_squared_error(newdf[sigma], Sig_pred_regr)))
            outFile.write('\n\tRMSE       -->     {:.3f}'.format(sqrt(mean_squared_error(newdf[sigma], Sig_pred_regr))))
            outFile.write('\n\tR²         -->     {:.3f}'.format(r2_score(newdf[sigma], Sig_pred_regr)))            
            outFile.write('\n\n\tCross Validation: Leave-One-Out (LOO)\n')
            outFile.write('\n\nPredicted Sigmas (cross-validation)\n\n')
            for j in Sig_pred_cv:
                outFile.write(str(j))
                outFile.write('\n')
            outFile.write('\n\tMSE(LOO)   -->     {:.3f}'.format(mean_squared_error(newdf[sigma], Sig_pred_cv)))
            outFile.write('\n\tRMSE(LOO)  -->     {:.3f}'.format(sqrt(mean_squared_error(newdf[sigma], Sig_pred_cv))))
            outFile.write('\n\tR(LOO)     -->     {:.3f}\n'.format(r2_score(newdf[sigma], Sig_pred_cv)))

outFile.close()

print('\nJob terminated.\n')